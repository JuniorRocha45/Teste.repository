import xbmcaddon

MainBase = 'http://pastebin.com/raw/rRvUc1RE'
addon = xbmcaddon.Addon('plugin.video.Junior Rochatutoriais')